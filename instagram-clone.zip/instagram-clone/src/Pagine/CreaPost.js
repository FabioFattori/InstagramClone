import React, { useState } from "react";
import DAD from "../Componenti/DragAndDrop";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import "../CSS/CreatePost.css";
import { collection, addDoc, updateDoc, doc, getDoc } from "firebase/firestore";
import { DB } from "../Utils/firebase";

function CreaPost() {
  const [titolo, setTitolo] = useState("");

  const [descrizione, setDescrizione] = useState("");

  const [URL, setURL] = useState("");

  function AddPostToDB() {
    console.log();
    const collectionPosts = collection(DB, "Posts");

    addDoc(collectionPosts, {
      Creatore: "Users/" + localStorage.getItem("UserID").split("|")[1],
      Descrizione: descrizione,
      Titolo: titolo,
      img: URL,
    }).then((addResponse) => {
      const docRef = doc(
        DB,
        "Users",
        localStorage.getItem("UserID").split("|")[1]
      );
      getDoc(docRef).then((getResponse) => {
        var stringForFirebase = "Posts/" + addResponse.id;
        var postsOfUser = [];

        var appoggio =
          getResponse._document.data.value.mapValue.fields.Post.arrayValue
            .values;

        appoggio.forEach((element) => {
          postsOfUser.push(element.referenceValue.split("projects/my-ig-clone/databases/(default)/documents/")[1]);
        });

        setTimeout(() => {
          console.log(postsOfUser);
          postsOfUser.push(stringForFirebase);

          updateDoc(docRef, { Post: postsOfUser });
          console.log("DONE");
        }, 100);
      });
    });
  }

  return (
    <div className="ContentCreatePost">
      <Form>
        <Form.Group className="mb-3" controlId="formBasicText">
          <Form.Label>Titolo</Form.Label>
          <Form.Control
            type="text"
            placeholder="Titolo"
            onChange={(e) => setTitolo(e.target.value)}
            value={titolo}
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicText">
          <Form.Label>Descrizione</Form.Label>
          <Form.Control
            type="text"
            placeholder="Descrizione"
            onChange={(e) => setDescrizione(e.target.value)}
            value={descrizione}
          />
          <Form.Text className="text-muted">
            Scegliere attentamente i dati inseriti, perchè non sarà possibile
            modificarli
          </Form.Text>
        </Form.Group>

        {/*codice inserito per avere l'immagine del post, da implementare il drag and drop dell'imagine locale*/}
        <Form.Group className="mb-3" controlId="formBasicText">
          <Form.Label>URL immagine</Form.Label>
          <Form.Control
            type="text"
            placeholder="Link To Image"
            onChange={(e) => setURL(e.target.value)}
            value={URL}
          />
        </Form.Group>
      </Form>
      {/* <DAD /> */}

      <Button onClick={() => AddPostToDB()} variant="primary" type="submit">
        Crea Post
      </Button>
    </div>
  );
}

export default CreaPost;
