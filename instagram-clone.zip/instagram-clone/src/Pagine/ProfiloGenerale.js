import React from 'react'
import DisplyDataOfProfile from '../Componenti/DisplyDataOfProfile'
import GeneralProfile from '../Componenti/GeneralProfile'

function ProfiloNonGenerale() {
  return (
    <div>
      <DisplyDataOfProfile
        ID={localStorage.getItem("UserToShow").split("|")[1]}
        NickName={localStorage.getItem("UserToShow").split("|")[0]}
        PersonaleProfile={false}
      />
      <GeneralProfile
        ID={localStorage.getItem("UserToShow").split("|")[1]}
        NickName={localStorage.getItem("UserToShow").split("|")[0]}
      />
    </div>
  )
}

export default ProfiloNonGenerale