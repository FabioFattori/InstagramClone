import React, { useState } from "react";
import { DB } from "../Utils/firebase";
import { useHistory } from "react-router-dom";
import { collection, addDoc, getDocs } from "firebase/firestore";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Alert from "react-bootstrap/Alert";
import "../CSS/Registrazione.css";

function Registrazione() {
  const History = useHistory();

  React.useEffect(() => {
    console.log(localStorage.getItem("UserID"));
    if (localStorage.getItem("UserID") === null) {
    } else {
      History.push("/");
    }
  }, []);

  const [AlertErroreGiàPresente, setAlertErroreGiàPresente] = useState(false); //si attiva quando il nick name oppure l'email sono già presenti nel DB

  const [AlertErrore, setAlertErrore] = useState(false); //si attiva quando c'è qualsiasi errore

  const [AlertLoginUser, setAlertLoginUser] = useState(false); //si attiva quando un utente già registrato si logga

  const [AlertNuovoUser, setAlertNuovoUser] = useState(false); //si attiva quando un utente nuovo si registra per la prima volta

  const [email, setEmail] = useState("");

  const [nomeUtente, setNome] = useState("");

  const [pass, setPass] = useState("");

  const PushData = (e) => {
    e.preventDefault();

    const collectionUtente = collection(DB, "Users");

    if (email === "" || pass === "" || nomeUtente === "") {
      setAlertErrore(true);
      return;
    }
    getDocs(collectionUtente).then((response) => {
      const Users = response.docs.map((doc) => ({
        data: doc.data(),
        id: doc.id,
      }));

      var controllo;

      for (let index = 0; index < Users.length; index++) {
        if (
          Users[index].data.email === email ||
          Users[index].data.NomeUtente === nomeUtente
        ) {
          controllo = "GiàPresente";
          if (
            Users[index].data.email === email &&
            Users[index].data.NomeUtente === nomeUtente &&
            Users[index].data.pass === pass
          ) {
            controllo = Users[index].id;
          }
          index = Users.length;
        } else {
          controllo = "errore";
        }
      }

      if (controllo === "errore") {
        console.log("new User detected");

        //  codice che pusha i dati nel DB
        addDoc(collectionUtente, {
          email: email,
          pass: pass,
          NomeUtente: nomeUtente,
          Post: [],
          Seguiti: [],
        }).then((response) => {
          setAlertNuovoUser(true);
          setTimeout(() => {
            localStorage.setItem("UserID", email + "|" + response.id);
            History.push("/");
            window.location.reload();
          }, 700);
        });
      } else if (controllo === "GiàPresente") {
        setAlertErroreGiàPresente(true);
      } else {
        setAlertLoginUser(true);
        setTimeout(() => {
          localStorage.setItem("UserID", email + "|" + controllo);
          History.push("/");
          window.location.reload();
        }, 700);
      }
    });
  };

  return (
    <div className="body">
      <Form onSubmit={(e) => PushData(e)}>
        <Alert
          variant="danger"
          show={AlertErroreGiàPresente}
          onClose={() => setAlertErroreGiàPresente(false)}
          dismissible
        >
          <Alert.Heading>
            ERRORE! Email e/o il NickName inseriti esistono già!
          </Alert.Heading>
        </Alert>
        <Alert
          variant="danger"
          show={AlertErrore}
          onClose={() => setAlertErrore(false)}
          dismissible
        >
          <Alert.Heading>
            ERRORE! Controlla l'email inserita, il nome Utente e/o la password!
          </Alert.Heading>
        </Alert>
        <Alert show={AlertNuovoUser} variant="success">
          <Alert.Heading>
            Registrazione del nuvo Utente Avvenuta con Successo!
          </Alert.Heading>
        </Alert>
        <Alert show={AlertLoginUser} variant="success">
          <Alert.Heading>LogIn Avvenuto con Successo!</Alert.Heading>
        </Alert>
        <h1 className="Text">Registrati oppure Loggati</h1>
        <Form.Group className="mb-3 input" controlId="formBasicEmail">
          <Form.Label className="formLabel Text">Indirizzo Email</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter email"
            onChange={(e) => setEmail(e.target.value)}
            value={email}
          />
        </Form.Group>

        <Form.Group className="mb-3 input" controlId="formBasicEmail">
          <Form.Label className="formLabel Text">Nome Utente</Form.Label>
          <Form.Control
            type="textarea"
            placeholder="Enter NickName"
            onChange={(e) => setNome(e.target.value)}
            value={nomeUtente}
          />
        </Form.Group>

        <Form.Group className="mb-3 input" controlId="formBasicPassword">
          <Form.Label className="formLabel Text">Password</Form.Label>
          <Form.Control
            type="password"
            placeholder="Password"
            onChange={(e) => setPass(e.target.value)}
            value={pass}
          />
        </Form.Group>
        <Button variant="primary" type="submit">
          Iscriviti
        </Button>
      </Form>
    </div>
  );
}
export default Registrazione;
