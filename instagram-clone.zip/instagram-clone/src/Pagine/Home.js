import React, { useEffect, useState } from "react";
import Stack from "@mui/material/Stack";
import { useHistory } from "react-router-dom";
import "../CSS/Home.css";
import Alert from "@mui/material/Alert";
import GetAccount from "../Utils/GetAccountSeguitiDaUnUtente";
import GetPosts from "../Utils/GetPostGivenIDOfUser";

function Home() {
  const History = useHistory();
  var [AccountSeguiti, setAccount] = useState(null); //array di ID degli account che l'account principale segue
  const [AllPost, setPosts] = useState([]);

  function GetAllData() {
    setAccount(
      (AccountSeguiti = GetAccount(
        localStorage.getItem("UserID").split("|")[1]
      ))
    );
    setTimeout(function () {
      var PostsOfSingleAccount;
      AccountSeguiti.forEach((Account) => {
        PostsOfSingleAccount = GetPosts(Account);
      });
      setTimeout(function () {
        setPosts(PostsOfSingleAccount);
      }, 300);
    }, 300);
  }

  useEffect(() => {
    if (localStorage.getItem("UserID") === null) {
      History.push("/Registrazione");
    } else {
      GetAllData();
    }
  }, []);

  const GraficaPost = () => {
    if (AllPost.lenght === 0) {
      var toReturn = (
        <Alert variant="filled" className="Info" severity="info">
          Nessun Post per Adesso!
        </Alert>
      );

      return toReturn;
    } else {
      return AllPost;
    }
  };

  return (
    <Stack spacing={2} direction="column">
      <div>{GraficaPost()}</div>
    </Stack>
  );
}

export default Home;
