import React, { useEffect, useState } from "react";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import { DB } from "../Utils/firebase";
import { doc, getDoc } from "firebase/firestore";
import Post from "../Componenti/SinglePost";
import { useHistory } from "react-router-dom";
import "../CSS/Home.css"
import Alert from '@mui/material/Alert';


function Home() {
  const History = useHistory();

  const [AllPost, setPosts] = useState([]);

  useEffect(() => {
    if (localStorage.getItem("UserID") === null) {
      History.push("/Registrazione");
    } else {
      getPosts();
    }
  }, []);

  function getPosts() {
    const docRef = doc(
      DB,
      "Users",
      localStorage.getItem("UserID").split("|")[1]
    );

    var posts = [];
    getDoc(docRef).then((response) => {
      response._document.data.value.mapValue.fields.Post.arrayValue.values.forEach(
        (element) => {
          posts.push(element.referenceValue);
        }
      );

      var ToSetAllPosts=[]

      posts.forEach((singlePost) => {
        const postDocRef = doc(
          DB,
          "Posts",
          singlePost.split(
            "projects/my-ig-clone/databases/(default)/documents/Users/"
          )[1]
        );

        getDoc(postDocRef).then((response) => {
          console.log(
            response._document.data.value.mapValue.fields.Titolo.stringValue
          );
          const singlePost = (
            <Post 
              key={
                response._document.data.value.mapValue.fields.Titolo.stringValue
              }
              titolo={
                response._document.data.value.mapValue.fields.Titolo.stringValue
              }
              descrizione={
                response._document.data.value.mapValue.fields.Descrizione
                  .stringValue
              }
              img={
                response._document.data.value.mapValue.fields.img.stringValue
              }
            />
          );

          ToSetAllPosts.push(singlePost);
        });
      });
      setTimeout(() => {setPosts(ToSetAllPosts)},400)
    });
  }

const GraficaPost=()=>{
    if (AllPost.length===0) {
        console.log("here")
        var toReturn=<Alert variant="filled" className="Info" severity="info">
        Nessun Post per Adesso!
      </Alert>
        
        return toReturn
      } else {
        return AllPost;
      }
}


  return (
    <Stack spacing={2} direction="column">
      <div>
        {GraficaPost()}
      </div>
    </Stack>
  );
}

export default Home;
