import React from "react";
import GeneralProfile from "../Componenti/GeneralProfile";
import DisplyDataOfProfile from "../Componenti/DisplyDataOfProfile";

function ProfiloPersonale() {
  return (
    <div>
      <DisplyDataOfProfile
        ID={localStorage.getItem("UserID").split("|")[1]}
        NickName={localStorage.getItem("UserID").split("|")[0]}
        PersonaleProfile={true}
      />
      <GeneralProfile
        ID={localStorage.getItem("UserID").split("|")[1]}
        NickName={localStorage.getItem("UserID").split("|")[0]}
      />
    </div>
  );
}

export default ProfiloPersonale;
