import React from 'react'

function ProfiloPersonale() {
  return (
    <div>
        ProfiloPersonale
    </div>
  )
}

export default ProfiloPersonale