import React from "react";
import { DB } from "../Utils/firebase";
import { doc, getDoc } from "firebase/firestore";
import Post from "../Componenti/SinglePost";

function GetPostGivenIDOfUser(ID) {
  
  

    var ToSetAllPosts = [];
    const docRef = doc(DB, "Users", ID);

    var posts = [];
    getDoc(docRef).then((response) => {
      response._document.data.value.mapValue.fields.Post.arrayValue.values.forEach(
        (element) => {
          posts.push(element.referenceValue);
        }
      );

      posts.forEach((singlePost) => {
        const postDocRef = doc(
          DB,
          "Posts",
          singlePost.split(
            "projects/my-ig-clone/databases/(default)/documents/Posts/"
          )[1]
        );

        getDoc(postDocRef).then((response) => {
          const CreatorDocRef = doc(
            DB,
            "Users",
            response._document.data.value.mapValue.fields.Creatore.referenceValue.split(
              "projects/my-ig-clone/databases/(default)/documents/Users/"
            )[1]
          );

          var CreatorOfPost = null;

          getDoc(CreatorDocRef).then((variable) => {
            CreatorOfPost =
              variable._document.data.value.mapValue.fields.NomeUtente
                .stringValue;
          });

          setTimeout(() => {
            const singlePost = (
              <Post
                key={
                  response._document.data.value.mapValue.fields.Titolo
                    .stringValue
                }
                creatore={CreatorOfPost}
                titolo={
                  response._document.data.value.mapValue.fields.Titolo
                    .stringValue
                }
                descrizione={
                  response._document.data.value.mapValue.fields.Descrizione
                    .stringValue
                }
                img={
                  response._document.data.value.mapValue.fields.img.stringValue
                }
              />
            );

            ToSetAllPosts.push(singlePost);
          }, 100);
        });
      });
    });
  
  return ToSetAllPosts;
}

export default GetPostGivenIDOfUser;
