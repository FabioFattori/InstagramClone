import React from "react";
import { DB } from "../Utils/firebase";
import { doc, getDoc } from "firebase/firestore";

function GetAccountSeguitiDaUnUtente(IDUtente) {
  const docRef = doc(DB, "Users", IDUtente);

  var AccountSeguiti = [];
  getDoc(docRef).then((response) => {
    response._document.data.value.mapValue.fields.Seguiti.arrayValue.values.forEach(
      (element) => {
        AccountSeguiti.push(
          element.referenceValue.split(
            "projects/my-ig-clone/databases/(default)/documents/Users/"
          )[1]
        );
      }
    );
  });

  return AccountSeguiti;
}

export default GetAccountSeguitiDaUnUtente;
