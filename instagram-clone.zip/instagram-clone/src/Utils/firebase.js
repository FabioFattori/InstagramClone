import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  databaseURL: "http://my-ig-clone.firebaseio.com",
  apiKey: "AIzaSyDzsnnz9ljk_P5IAxxWCELRSZCbynal6iw",
  authDomain: "my-ig-clone.firebaseapp.com",
  projectId: "my-ig-clone",
  storageBucket: "my-ig-clone.appspot.com",
  messagingSenderId: "138476805140",
  appId: "1:138476805140:web:843941da784f1646a21b01",
};

// Import the functions you need from the SDKs you need

// Your web app's Firebase configuration

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const DB = getFirestore(app);
