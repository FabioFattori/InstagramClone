import React from "react";

import {
  red,
  purple,
  deepPurple,
  blue,
  orange,
  deepOrange,
  lightGreen,
} from "@mui/material/colors";

function ChoseColor() {
    
  function getRandomInt(max) {
    return Math.floor(Math.random() * max);
  }

  const color = () => {
    var chose = getRandomInt(7);

    switch (chose) {
      case 0:
        return red[500];
      case 1:
        return purple[500];

      case 2:
        return deepPurple[500];

      case 3:
        return blue[500];
      case 4:
        return orange[500];
      case 5:
        return deepOrange[500];
      case 6:
        return lightGreen.A400;
      default:
        break;
    }
  };
  return color;
}

export default ChoseColor;
