import "./App.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import Home from "./Pagine/Home";
import MyProfilo from "./Pagine/ProfiloPersonale";
import OtherProfile from "./Pagine/ProfiloGenerale"
import NavBar from "./Componenti/NavBar"
import Reg from "./Pagine/Registrazione"
import { BrowserRouter, Switch, Route } from "react-router-dom";
import CreaPost from "./Pagine/CreaPost"

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <NavBar />
        <Switch>
        <Route path="/Registrazione">
            <Reg />
          </Route>
          <Route path="/ProfiloPersonale">
            <MyProfilo />
          </Route>
          <Route path="/OtherProfile">
            <OtherProfile />
          </Route>
          <Route path="/CreatePost">
            <CreaPost />
          </Route>
          <Route path="/">
            <Home />
          </Route>

          <Route path="*">
            <div>
              <h1>ERRORE 404</h1>
            </div>
          </Route>
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
