import React, { Component } from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import "../CSS/SinglePost.css";
import Stack from "@mui/material/Stack";
import { DB } from "../Utils/firebase";
import { doc, getDoc } from "firebase/firestore";
import "../CSS/DiplayDataOfProfile.css";
import Button from "@mui/material/Button";
import GetAccountSeguitiDaUnUtente from "../Utils/GetAccountSeguitiDaUnUtente";

export class DisplyDataOfProfile extends Component {
  constructor(props) {
    super(props);

    this.state = {
      Id: props.ID,
      nomeUtente: props.NickName,
      isProfiloPersonale: props.PersonaleProfile,
      TotaleSeguiti: 0,
      TotaleFollowers: 0,
      TotalePost: 0,
    };

    this.CheckIfTheMainUserFollowThisUser =
      this.CheckIfTheMainUserFollowThisUser.bind(this);
  }

  componentDidMount() {
    const docRef = doc(DB, "Users", this.state.Id);

    getDoc(docRef).then((response) => {
      try {
        this.setState({
          TotaleSeguiti:
            response._document.data.value.mapValue.fields.Seguiti.arrayValue
              .values.length,
        });
      } catch (error) {
        //array in DB vuoto - do nothing
      }

      try {
        this.setState({
          TotaleFollowers:
            response._document.data.value.mapValue.fields.Followers.arrayValue
              .values.length,
        });
      } catch (error) {
        //array in DB vuoto - do nothing
      }

      try {
        this.setState({
          TotalePost:
            response._document.data.value.mapValue.fields.Post.arrayValue.values
              .length,
        });
      } catch (error) {
        //array in DB vuoto - do nothing
      }
    });
  }

  async CheckIfTheMainUserFollowThisUser() {
    let returned = false;
    let array = GetAccountSeguitiDaUnUtente(
      localStorage.getItem("UserID").split("|")[1]
    );

    for (let index = 0; index < array.length; index++) {
      if (array[index] === this.state.Id) {
        returned = true;
        break;
      }
    }
    return returned;
   
  }

  render() {
    const MyPersonalProfile = () => {
      if (this.state.isProfiloPersonale) {
        return (
          <Typography gutterBottom variant="h9" component="div">
            Il tuo Profilo Personale
          </Typography>
        );
      } else if (this.CheckIfTheMainUserFollowThisUser()) {
        return (
          <Button variant="contained" disabled>
            Segui Già questo Account
          </Button>
        );
      } else {
        return <Button variant="contained">Segui</Button>;
      }
    };

    return (
      <Card className="TotalCard" sx={{ maxWidth: 1 / 2 }}>
        <CardContent>
          <Typography gutterBottom variant="h5" component="div">
            {this.state.nomeUtente}
          </Typography>
          {MyPersonalProfile()}
          <Typography variant="body2" color="text.secondary">
            <Stack
              direction="row"
              justifyContent="center"
              alignItems="center"
              spacing={12}
              className="DataContainer"
            >
              <div>
                <Typography gutterBottom variant="h7" component="div">
                  Account Seguiti:
                </Typography>
                <Typography gutterBottom variant="h5" component="div">
                  {this.state.TotaleSeguiti}
                </Typography>
              </div>
              <div>
                <Typography gutterBottom variant="h7" component="div">
                  Followers:
                </Typography>
                <Typography gutterBottom variant="h5" component="div">
                  {this.state.TotaleFollowers}
                </Typography>
              </div>
              <div>
                <Typography gutterBottom variant="h7" component="div">
                  Totale Post:
                </Typography>
                <Typography gutterBottom variant="h5" component="div">
                  {this.state.TotalePost}
                </Typography>
              </div>
            </Stack>
          </Typography>
        </CardContent>
      </Card>
    );
  }
}

export default DisplyDataOfProfile;
