import "../CSS/SinglePost.css"
import { styled } from "@mui/material/styles";
import Card from "@mui/material/Card";
import CardHeader from "@mui/material/CardHeader";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import CardActions from "@mui/material/CardActions";
import Avatar from "@mui/material/Avatar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import { red } from "@mui/material/colors";
import FavoriteIcon from "@mui/icons-material/FavoriteOutlined";
import ShareIcon from "@mui/icons-material/Share";
import MoreVertIcon from "@mui/icons-material/MoreVert";

import React, { Component } from 'react'

export class SinglePost extends Component {
    constructor(props) {
        super(props);

        this.state={
            titolo:props.titolo,
            descrizione:props.descrizione,
            img:props.img,

        }
    }


  render() {
    function Oggi() {
        var today = new Date();
        var date =
          today.getDate() +
          "-" +
          (today.getMonth() + 1) +
          "-" +
          today.getFullYear();
    
        return date;
      }


    return (
        <Card className="TotalCard" sx={{ maxWidth: 1/2 }}>
        <CardHeader
          avatar={
            <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
              R
            </Avatar>
          }
          action={
            <IconButton aria-label="settings">
              <MoreVertIcon />
            </IconButton>
          }
          title={this.state.titolo}
          subheader={Oggi()}
        />
        <CardMedia
          component="img"
          height="600"
          image={this.state.img}
          alt="Post Image"
        />
        <CardContent>
          <Typography variant="body2" color="text.secondary">
            {this.state.descrizione}
          </Typography>
        </CardContent>
        <CardActions disableSpacing>
          <IconButton aria-label="add to favorites">
            <FavoriteIcon />
          </IconButton>
          <IconButton aria-label="share">
            <ShareIcon />
          </IconButton>
        </CardActions>
      </Card>
    )
  }
}

export default SinglePost




