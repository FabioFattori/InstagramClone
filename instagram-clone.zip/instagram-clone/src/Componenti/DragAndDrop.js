import React, { useState } from "react"
import { useDropzone } from "react-dropzone"
import Button from '@mui/material/Button';
import "../CSS/DragAndDrop.css"

function DAD() {
  const [files, setFiles] = useState([])

  const { getRootProps, getInputProps } = useDropzone({
    accept: "image/*",
    onDrop: (acceptedFiles) => {
      setFiles(
        acceptedFiles.map((file) =>
          Object.assign(file, {
            preview: URL.createObjectURL(file),
          })
        )
      )
    },
  })

  const images = files.map((file) => (
    <div key={file.name}>
      <div>
        <img src={file.preview} style={{ width: "1000px" }} alt="preview" />
      </div>
    </div>
  ))

  return (
    <div className="DADContainer">
      <div className="DADContent" {...getRootProps()}>
        <input {...getInputProps()} />
        <p className="DADText">Puoi cliccare ovunque dentro all'area delimitata dal bordo per importare la tua foto, Oppure trascinala qui!</p>
        <Button variant="contained">importa la tua foto Qui</Button>

      </div>
      {console.log(images[0])}
      <div>{images}</div>
    </div>
  )
}

export default DAD