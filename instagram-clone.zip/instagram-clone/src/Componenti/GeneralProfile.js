import React, { Component } from "react";
import { DB } from "../Utils/firebase";
import { doc, getDoc } from "firebase/firestore";
import Post from "../Componenti/SinglePost";
import Alert from "@mui/material/Alert";

export class GeneralProfile extends Component {
  constructor(props) {
    super(props);

    this.state = {
      IDofUser: props.ID,
      NomeUtente: props.NickName,
      AllPosts: [],
    };
  }

  componentDidMount() {
    if (this.state.IDofUser === null) {
      //caso che si verifica solo quando vado a vedere il profilo di un altro utente:
      const docRef = doc(DB, "Users");

      getDoc(docRef).then((response) => {
        console.log(response._document.data);
      });
    }

    const docRef = doc(DB, "Users", this.state.IDofUser);

    var posts = [];
    getDoc(docRef).then((response) => {
      response._document.data.value.mapValue.fields.Post.arrayValue.values.forEach(
        (element) => {
          posts.push(element.referenceValue);
        }
      );

      var ToSetAllPosts = [];

      posts.forEach((singlePost) => {
        const postDocRef = doc(
          DB,
          "Posts",
          singlePost.split(
            "projects/my-ig-clone/databases/(default)/documents/Posts/"
          )[1]
        );

        getDoc(postDocRef).then((response) => {
          const CreatorDocRef = doc(
            DB,
            "Users",
            response._document.data.value.mapValue.fields.Creatore.referenceValue.split(
              "projects/my-ig-clone/databases/(default)/documents/Users/"
            )[1]
          );

          var CreatorOfPost = null;

          getDoc(CreatorDocRef).then((variable) => {
            CreatorOfPost =
              variable._document.data.value.mapValue.fields.NomeUtente
                .stringValue;
          });

          setTimeout(() => {

            const singlePost = (
              <Post
                key={
                  response._document.data.value.mapValue.fields.Titolo
                    .stringValue
                }
                creatore={CreatorOfPost}
                titolo={
                  response._document.data.value.mapValue.fields.Titolo
                    .stringValue
                }
                descrizione={
                  response._document.data.value.mapValue.fields.Descrizione
                    .stringValue
                }
                img={
                  response._document.data.value.mapValue.fields.img.stringValue
                }
              />
            );

            ToSetAllPosts.push(singlePost);
          }, 100);
        });
      });
      setTimeout(() => {
        this.setState({ AllPosts: ToSetAllPosts });
      }, 400);
    });
  }

  render() {
    const GraficaPost = () => {
      if (this.state.AllPosts.length === 0) {
        var toReturn = (
          <Alert variant="filled" className="Info" severity="info">
            Nessun Post per Adesso!
          </Alert>
        );

        return toReturn;
      } else {
        return this.state.AllPosts;
      }
    };

    return <div>{GraficaPost()}</div>;
  }
}

export default GeneralProfile;
